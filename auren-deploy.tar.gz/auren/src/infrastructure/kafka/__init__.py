"""Kafka infrastructure for AUREN event pipeline."""
