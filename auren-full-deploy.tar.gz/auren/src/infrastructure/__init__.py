"""AUREN infrastructure layer - Kafka, databases, and external integrations."""
