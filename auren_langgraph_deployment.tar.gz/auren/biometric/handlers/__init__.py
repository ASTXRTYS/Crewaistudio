"""Biometric device webhook handlers"""

from ..handlers import AppleHealthKitHandler

__all__ = ["AppleHealthKitHandler"] 