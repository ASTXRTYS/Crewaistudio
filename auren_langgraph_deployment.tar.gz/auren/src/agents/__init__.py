# AUREN Agents Module
from .neuroscientist import NeuroscientistAgent

__all__ = ['NeuroscientistAgent']
