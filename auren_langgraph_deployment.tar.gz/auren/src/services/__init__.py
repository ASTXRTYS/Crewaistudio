"""Services layer for AUREN - clean APIs for complex operations."""
