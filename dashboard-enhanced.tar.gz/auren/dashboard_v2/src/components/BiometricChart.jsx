import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';

// Expert-Level Biometric Time-Series Visualization
const BiometricChart = ({ 
  data = [], 
  type = 'line', // line, area, heatmap
  metric = 'heartRate',
  showAnomalies = true,
  realtime = true,
  height = 300,
  colorScheme = 'biometric'
}) => {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 800, height });
  const [hoveredPoint, setHoveredPoint] = useState(null);

  // Color schemes from training guide
  const colorSchemes = {
    biometric: {
      primary: '#4ade80',
      secondary: '#22c55e',
      danger: '#f87171',
      warning: '#fbbf24',
      gradient: ['#065f46', '#10b981', '#6ee7b7']
    },
    neural: {
      primary: '#9A97F3',
      secondary: '#8b5cf6',
      danger: '#f87171',
      warning: '#fbbf24',
      gradient: ['#4c1d95', '#8b5cf6', '#c4b5fd']
    }
  };

  const colors = colorSchemes[colorScheme] || colorSchemes.biometric;

  // Metric configurations based on training guide
  const metricConfigs = {
    heartRate: {
      label: 'Heart Rate (BPM)',
      normalRange: [60, 100],
      criticalLow: 50,
      criticalHigh: 120,
      unit: 'bpm'
    },
    hrv: {
      label: 'HRV (ms)',
      normalRange: [20, 200],
      criticalLow: 10,
      criticalHigh: 250,
      unit: 'ms'
    },
    bloodOxygen: {
      label: 'SpO2 (%)',
      normalRange: [95, 100],
      criticalLow: 90,
      criticalHigh: 100,
      unit: '%'
    },
    temperature: {
      label: 'Temperature (°C)',
      normalRange: [36.5, 37.5],
      criticalLow: 35.5,
      criticalHigh: 38.5,
      unit: '°C'
    }
  };

  const config = metricConfigs[metric] || metricConfigs.heartRate;

  useEffect(() => {
    // Responsive sizing
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: height
        });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [height]);

  useEffect(() => {
    if (!data.length) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 20, right: 80, bottom: 40, left: 60 };
    const width = dimensions.width - margin.left - margin.right;
    const height = dimensions.height - margin.top - margin.bottom;

    // Create main group
    const g = svg
      .attr('width', dimensions.width)
      .attr('height', dimensions.height)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Scales
    const xScale = d3.scaleTime()
      .domain(d3.extent(data, d => new Date(d.timestamp)))
      .range([0, width]);

    const yScale = d3.scaleLinear()
      .domain([
        Math.min(config.criticalLow, d3.min(data, d => d.value) * 0.9),
        Math.max(config.criticalHigh, d3.max(data, d => d.value) * 1.1)
      ])
      .range([height, 0]);

    // Add gradient definitions
    const defs = svg.append('defs');
    
    // Area gradient
    const gradient = defs.append('linearGradient')
      .attr('id', 'area-gradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    gradient.append('stop')
      .attr('offset', '0%')
      .attr('stop-color', colors.primary)
      .attr('stop-opacity', 0.6);

    gradient.append('stop')
      .attr('offset', '100%')
      .attr('stop-color', colors.primary)
      .attr('stop-opacity', 0.1);

    // Add axes
    const xAxis = d3.axisBottom(xScale)
      .tickFormat(d3.timeFormat('%H:%M'))
      .tickSize(-height)
      .tickPadding(10);

    const yAxis = d3.axisLeft(yScale)
      .tickSize(-width)
      .tickPadding(10);

    // X-axis
    g.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${height})`)
      .call(xAxis)
      .style('color', 'rgba(255, 255, 255, 0.3)')
      .selectAll('line')
      .style('stroke', 'rgba(255, 255, 255, 0.1)');

    // Y-axis
    g.append('g')
      .attr('class', 'y-axis')
      .call(yAxis)
      .style('color', 'rgba(255, 255, 255, 0.3)')
      .selectAll('line')
      .style('stroke', 'rgba(255, 255, 255, 0.1)');

    // Add normal range band
    g.append('rect')
      .attr('x', 0)
      .attr('y', yScale(config.normalRange[1]))
      .attr('width', width)
      .attr('height', yScale(config.normalRange[0]) - yScale(config.normalRange[1]))
      .attr('fill', colors.primary)
      .attr('opacity', 0.1);

    // Add critical zones
    // Upper critical
    g.append('rect')
      .attr('x', 0)
      .attr('y', 0)
      .attr('width', width)
      .attr('height', yScale(config.criticalHigh))
      .attr('fill', colors.danger)
      .attr('opacity', 0.05);

    // Lower critical
    g.append('rect')
      .attr('x', 0)
      .attr('y', yScale(config.criticalLow))
      .attr('width', width)
      .attr('height', height - yScale(config.criticalLow))
      .attr('fill', colors.danger)
      .attr('opacity', 0.05);

    if (type === 'area' || type === 'line') {
      // Area generator
      const area = d3.area()
        .x(d => xScale(new Date(d.timestamp)))
        .y0(height)
        .y1(d => yScale(d.value))
        .curve(d3.curveMonotoneX);

      // Line generator
      const line = d3.line()
        .x(d => xScale(new Date(d.timestamp)))
        .y(d => yScale(d.value))
        .curve(d3.curveMonotoneX);

      if (type === 'area') {
        // Add area
        g.append('path')
          .datum(data)
          .attr('fill', 'url(#area-gradient)')
          .attr('d', area)
          .style('opacity', 0)
          .transition()
          .duration(1000)
          .style('opacity', 1);
      }

      // Add line
      const path = g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', colors.primary)
        .attr('stroke-width', 2)
        .attr('d', line);

      // Animate line drawing
      const totalLength = path.node().getTotalLength();
      path
        .attr('stroke-dasharray', totalLength + ' ' + totalLength)
        .attr('stroke-dashoffset', totalLength)
        .transition()
        .duration(2000)
        .ease(d3.easeLinear)
        .attr('stroke-dashoffset', 0);

      // Add glow effect
      path.style('filter', 'drop-shadow(0 0 8px ' + colors.primary + ')');
    }

    // Add anomaly markers
    if (showAnomalies) {
      const anomalies = data.filter(d => 
        d.value < config.normalRange[0] || d.value > config.normalRange[1]
      );

      g.selectAll('.anomaly')
        .data(anomalies)
        .enter()
        .append('circle')
        .attr('class', 'anomaly')
        .attr('cx', d => xScale(new Date(d.timestamp)))
        .attr('cy', d => yScale(d.value))
        .attr('r', 0)
        .attr('fill', colors.danger)
        .attr('stroke', colors.danger)
        .attr('stroke-width', 2)
        .attr('fill-opacity', 0.3)
        .style('filter', 'drop-shadow(0 0 12px ' + colors.danger + ')')
        .transition()
        .delay((d, i) => i * 50)
        .duration(500)
        .attr('r', 6);

      // Add pulse animation to anomalies
      g.selectAll('.anomaly')
        .append('animate')
        .attr('attributeName', 'r')
        .attr('values', '6;8;6')
        .attr('dur', '2s')
        .attr('repeatCount', 'indefinite');
    }

    // Add interactive overlay
    const tooltip = d3.select('body').append('div')
      .attr('class', 'biometric-tooltip')
      .style('opacity', 0)
      .style('position', 'absolute')
      .style('background', 'rgba(0, 0, 0, 0.9)')
      .style('border', '1px solid ' + colors.primary)
      .style('border-radius', '8px')
      .style('padding', '12px')
      .style('color', 'white')
      .style('font-size', '14px')
      .style('pointer-events', 'none')
      .style('backdrop-filter', 'blur(10px)');

    // Add invisible points for hover
    g.selectAll('.hover-point')
      .data(data)
      .enter()
      .append('circle')
      .attr('class', 'hover-point')
      .attr('cx', d => xScale(new Date(d.timestamp)))
      .attr('cy', d => yScale(d.value))
      .attr('r', 8)
      .attr('fill', 'transparent')
      .on('mouseover', (event, d) => {
        setHoveredPoint(d);
        tooltip.transition().duration(200).style('opacity', 1);
        tooltip.html(`
          <div style="font-weight: bold; margin-bottom: 4px;">${config.label}</div>
          <div>Value: ${d.value} ${config.unit}</div>
          <div>Time: ${new Date(d.timestamp).toLocaleTimeString()}</div>
          ${d.value < config.normalRange[0] || d.value > config.normalRange[1] 
            ? '<div style="color: ' + colors.danger + '; margin-top: 4px;">⚠️ Anomaly Detected</div>' 
            : ''}
        `)
        .style('left', (event.pageX + 10) + 'px')
        .style('top', (event.pageY - 28) + 'px');
      })
      .on('mouseout', () => {
        setHoveredPoint(null);
        tooltip.transition().duration(500).style('opacity', 0);
      });

    // Cleanup
    return () => {
      d3.select('body').selectAll('.biometric-tooltip').remove();
    };
  }, [data, type, dimensions, config, colors, showAnomalies]);

  return (
    <motion.div
      ref={containerRef}
      className="biometric-chart glass-panel"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      style={{
        width: '100%',
        height: dimensions.height,
        padding: '20px',
        position: 'relative'
      }}
    >
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '16px'
      }}>
        <h3 style={{
          margin: 0,
          fontSize: '18px',
          fontWeight: '600',
          color: 'var(--text-high-emphasis)'
        }}>
          {config.label}
        </h3>
        {realtime && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: colors.primary,
              animation: 'pulse 2s infinite'
            }} />
            <span style={{
              fontSize: '14px',
              color: 'var(--text-medium-emphasis)'
            }}>
              Live
            </span>
          </div>
        )}
      </div>
      <svg ref={svgRef} />
      <style jsx>{`
        @keyframes pulse {
          0% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.5;
            transform: scale(1.2);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </motion.div>
  );
};

export default BiometricChart; 