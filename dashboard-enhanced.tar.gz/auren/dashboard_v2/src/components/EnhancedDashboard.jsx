import { createSignal, onMount, onCleanup, Show, For } from 'solid-js';
import { motion } from '@motionone/solid';
import './glassmorphism.css';

// Import new components (these would be converted to SolidJS)
// For now, we'll create inline implementations

const EnhancedDashboard = () => {
  const [activeView, setActiveView] = createSignal('overview');
  const [selectedAgent, setSelectedAgent] = createSignal('neuroscientist');
  const [biometricData, setBiometricData] = createSignal([]);
  const [showParticles, setShowParticles] = createSignal(true);
  
  // Mock biometric data for demonstration
  onMount(() => {
    // Generate mock time-series data
    const generateBiometricData = () => {
      const now = Date.now();
      const data = [];
      for (let i = 0; i < 100; i++) {
        data.push({
          timestamp: now - (100 - i) * 60000, // 1 minute intervals
          value: 60 + Math.random() * 40 + Math.sin(i / 10) * 10,
          metric: 'heartRate'
        });
      }
      setBiometricData(data);
    };
    
    generateBiometricData();
    const interval = setInterval(generateBiometricData, 5000);
    
    onCleanup(() => clearInterval(interval));
  });

  // Navigation items with glassmorphism
  const navItems = [
    { id: 'overview', label: 'Overview', icon: '🧠' },
    { id: 'agents', label: 'AI Agents', icon: '🤖' },
    { id: 'biometrics', label: 'Biometrics', icon: '💓' },
    { id: 'knowledge', label: 'Knowledge Graph', icon: '🕸️' },
    { id: 'analytics', label: 'Analytics', icon: '📊' }
  ];

  return (
    <div class="enhanced-dashboard">
      {/* Particle Background */}
      <Show when={showParticles()}>
        <div class="particle-container">
          <canvas id="particles-canvas" />
        </div>
      </Show>

      {/* Glassmorphic Navigation Bar */}
      <nav class="glass-panel nav-bar">
        <div class="nav-content">
          <div class="logo-section glass-glow-primary">
            <h1 class="logo-text">AUREN</h1>
            <span class="logo-subtitle">Neural Consciousness Monitor</span>
          </div>
          
          <div class="nav-items">
            <For each={navItems}>
              {(item) => (
                <motion.button
                  class={`glass-button nav-item ${activeView() === item.id ? 'active' : ''}`}
                  onClick={() => setActiveView(item.id)}
                  animate={{ 
                    scale: activeView() === item.id ? 1.05 : 1,
                    backgroundColor: activeView() === item.id 
                      ? 'rgba(154, 151, 243, 0.2)' 
                      : 'rgba(255, 255, 255, 0.05)'
                  }}
                  transition={{ duration: 0.2 }}
                >
                  <span class="nav-icon">{item.icon}</span>
                  <span class="nav-label">{item.label}</span>
                </motion.button>
              )}
            </For>
          </div>

          <div class="status-section">
            <div class="connection-status glass-surface">
              <div class="status-indicator pulse-green" />
              <span class="status-text">Live</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main class="dashboard-content">
        {/* Overview View */}
        <Show when={activeView() === 'overview'}>
          <div class="view-container">
            <motion.div 
              class="metrics-grid"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* KPI Cards with Glassmorphism */}
              <div class="glass-card metric-card">
                <div class="metric-header">
                  <h3>Neural Activity</h3>
                  <span class="metric-trend trend-up">↑ 12%</span>
                </div>
                <div class="metric-value">
                  <span class="value">87.3</span>
                  <span class="unit">%</span>
                </div>
                <div class="metric-chart">
                  <svg viewBox="0 0 100 40" class="mini-chart">
                    <path 
                      d="M0,30 L20,25 L40,15 L60,20 L80,10 L100,5" 
                      stroke="var(--accent-success)" 
                      stroke-width="2" 
                      fill="none"
                      style="filter: drop-shadow(0 0 8px var(--accent-success))"
                    />
                  </svg>
                </div>
              </div>

              <div class="glass-card metric-card">
                <div class="metric-header">
                  <h3>Knowledge Nodes</h3>
                  <span class="metric-trend">+245</span>
                </div>
                <div class="metric-value">
                  <span class="value">12.4K</span>
                </div>
                <div class="metric-progress">
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: 78%"></div>
                  </div>
                </div>
              </div>

              <div class="glass-card metric-card alert">
                <div class="metric-header">
                  <h3>Anomalies</h3>
                  <span class="alert-badge">3 Active</span>
                </div>
                <div class="anomaly-list">
                  <div class="anomaly-item">
                    <span class="anomaly-icon">⚠️</span>
                    <span>HRV Pattern Deviation</span>
                  </div>
                  <div class="anomaly-item">
                    <span class="anomaly-icon">⚡</span>
                    <span>Cognitive Load Spike</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Real-time Activity Feed */}
            <motion.div 
              class="glass-panel activity-feed"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 class="panel-title">Real-time Activity</h2>
              <div class="activity-stream">
                <div class="activity-item glass-surface">
                  <div class="activity-icon hypothesis">💡</div>
                  <div class="activity-content">
                    <p class="activity-text">New hypothesis generated: Sleep pattern correlation with cognitive performance</p>
                    <span class="activity-time">2 min ago</span>
                  </div>
                </div>
                <div class="activity-item glass-surface">
                  <div class="activity-icon knowledge">🧩</div>
                  <div class="activity-content">
                    <p class="activity-text">Knowledge graph expanded: 45 new connections identified</p>
                    <span class="activity-time">5 min ago</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </Show>

        {/* Biometrics View */}
        <Show when={activeView() === 'biometrics'}>
          <div class="view-container biometrics-view">
            <motion.div 
              class="glass-panel biometric-panel"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <h2 class="panel-title">Biometric Monitoring</h2>
              
              {/* Biometric Chart Placeholder */}
              <div class="chart-container glass-surface">
                <div class="chart-header">
                  <h3>Heart Rate Variability</h3>
                  <div class="chart-controls">
                    <button class="glass-button chart-btn">1H</button>
                    <button class="glass-button chart-btn active">24H</button>
                    <button class="glass-button chart-btn">7D</button>
                  </div>
                </div>
                <div class="chart-area">
                  {/* Chart would be rendered here */}
                  <div class="chart-placeholder">
                    <svg viewBox="0 0 800 300" class="biometric-chart-svg">
                      <defs>
                        <linearGradient id="biometric-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stop-color="var(--accent-success)" stop-opacity="0.6" />
                          <stop offset="100%" stop-color="var(--accent-success)" stop-opacity="0.1" />
                        </linearGradient>
                      </defs>
                      <path 
                        d="M0,200 Q100,150 200,180 T400,160 T600,140 T800,150" 
                        stroke="var(--accent-success)" 
                        stroke-width="3" 
                        fill="url(#biometric-gradient)"
                        style="filter: drop-shadow(0 0 12px var(--accent-success))"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Biometric Stats Grid */}
              <div class="biometric-stats-grid">
                <div class="glass-card stat-card">
                  <div class="stat-icon">💓</div>
                  <div class="stat-content">
                    <h4>Avg Heart Rate</h4>
                    <p class="stat-value">72 <span class="stat-unit">bpm</span></p>
                  </div>
                </div>
                <div class="glass-card stat-card">
                  <div class="stat-icon">🌡️</div>
                  <div class="stat-content">
                    <h4>Temperature</h4>
                    <p class="stat-value">36.8 <span class="stat-unit">°C</span></p>
                  </div>
                </div>
                <div class="glass-card stat-card">
                  <div class="stat-icon">💨</div>
                  <div class="stat-content">
                    <h4>SpO2</h4>
                    <p class="stat-value">98 <span class="stat-unit">%</span></p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </Show>
      </main>

      {/* Floating Action Buttons */}
      <div class="fab-container">
        <motion.button 
          class="glass-button fab"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowParticles(!showParticles())}
        >
          {showParticles() ? '✨' : '🌑'}
        </motion.button>
      </div>

      <style>{`
        .enhanced-dashboard {
          min-height: 100vh;
          background: var(--deep-space);
          position: relative;
          overflow: hidden;
        }

        .particle-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 0;
          opacity: 0.7;
        }

        .nav-bar {
          position: sticky;
          top: 0;
          z-index: 100;
          margin: 20px;
          padding: 20px 30px;
        }

        .nav-content {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 40px;
        }

        .logo-section {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .logo-text {
          font-size: 28px;
          font-weight: 700;
          margin: 0;
          background: linear-gradient(135deg, var(--neural-pink), var(--neural-purple));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          filter: drop-shadow(0 0 20px rgba(154, 151, 243, 0.5));
        }

        .logo-subtitle {
          font-size: 12px;
          color: var(--text-medium-emphasis);
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        .nav-items {
          display: flex;
          gap: 12px;
          flex: 1;
          justify-content: center;
        }

        .nav-item {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 20px;
          font-size: 14px;
          font-weight: 500;
          white-space: nowrap;
        }

        .nav-item.active {
          box-shadow: 
            0 4px 20px rgba(154, 151, 243, 0.3),
            inset 0 0 20px rgba(154, 151, 243, 0.1);
        }

        .nav-icon {
          font-size: 18px;
        }

        .connection-status {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          border-radius: 20px;
        }

        .status-indicator {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: var(--accent-success);
        }

        .pulse-green {
          animation: pulse-green 2s infinite;
        }

        @keyframes pulse-green {
          0%, 100% {
            opacity: 1;
            box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7);
          }
          50% {
            opacity: 0.7;
            box-shadow: 0 0 0 8px rgba(74, 222, 128, 0);
          }
        }

        .dashboard-content {
          padding: 20px;
          position: relative;
          z-index: 10;
        }

        .view-container {
          max-width: 1400px;
          margin: 0 auto;
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }

        .metric-card {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .metric-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .metric-header h3 {
          margin: 0;
          font-size: 16px;
          color: var(--text-medium-emphasis);
        }

        .metric-trend {
          font-size: 14px;
          font-weight: 600;
        }

        .trend-up {
          color: var(--accent-success);
        }

        .metric-value {
          display: flex;
          align-items: baseline;
          gap: 4px;
        }

        .metric-value .value {
          font-size: 36px;
          font-weight: 700;
          color: var(--text-high-emphasis);
        }

        .metric-value .unit {
          font-size: 18px;
          color: var(--text-medium-emphasis);
        }

        .mini-chart {
          width: 100%;
          height: 40px;
        }

        .progress-bar {
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--accent-primary), var(--accent-info));
          border-radius: 3px;
          transition: width 0.5s ease;
        }

        .alert-badge {
          padding: 4px 12px;
          background: rgba(248, 113, 113, 0.2);
          color: var(--accent-danger);
          border-radius: 12px;
          font-size: 12px;
          font-weight: 600;
        }

        .anomaly-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .anomaly-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: rgba(248, 113, 113, 0.1);
          border-radius: 8px;
          border: 1px solid rgba(248, 113, 113, 0.2);
        }

        .activity-feed {
          padding: 24px;
        }

        .panel-title {
          margin: 0 0 20px 0;
          font-size: 20px;
          font-weight: 600;
          color: var(--text-high-emphasis);
        }

        .activity-stream {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .activity-item {
          display: flex;
          gap: 16px;
          padding: 16px;
          border-radius: 12px;
          transition: all 0.2s ease;
        }

        .activity-item:hover {
          transform: translateX(4px);
        }

        .activity-icon {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 12px;
          font-size: 20px;
        }

        .activity-icon.hypothesis {
          background: rgba(154, 151, 243, 0.2);
        }

        .activity-icon.knowledge {
          background: rgba(74, 222, 128, 0.2);
        }

        .activity-content {
          flex: 1;
        }

        .activity-text {
          margin: 0 0 4px 0;
          color: var(--text-high-emphasis);
        }

        .activity-time {
          font-size: 12px;
          color: var(--text-disabled);
        }

        .biometrics-view {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        .biometric-panel {
          padding: 30px;
        }

        .chart-container {
          padding: 20px;
          border-radius: 16px;
          margin-bottom: 24px;
        }

        .chart-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .chart-header h3 {
          margin: 0;
          font-size: 18px;
          color: var(--text-high-emphasis);
        }

        .chart-controls {
          display: flex;
          gap: 8px;
        }

        .chart-btn {
          padding: 6px 16px;
          font-size: 12px;
          font-weight: 600;
        }

        .chart-btn.active {
          background: var(--accent-primary);
          color: white;
        }

        .chart-area {
          height: 300px;
          position: relative;
        }

        .biometric-chart-svg {
          width: 100%;
          height: 100%;
        }

        .biometric-stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 16px;
        }

        .stat-card {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 20px;
        }

        .stat-icon {
          font-size: 32px;
        }

        .stat-content h4 {
          margin: 0 0 8px 0;
          font-size: 14px;
          color: var(--text-medium-emphasis);
        }

        .stat-value {
          margin: 0;
          font-size: 24px;
          font-weight: 700;
          color: var(--text-high-emphasis);
        }

        .stat-unit {
          font-size: 16px;
          color: var(--text-medium-emphasis);
          font-weight: 400;
        }

        .fab-container {
          position: fixed;
          bottom: 30px;
          right: 30px;
          z-index: 100;
        }

        .fab {
          width: 56px;
          height: 56px;
          border-radius: 50%;
          font-size: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 
            0 6px 20px rgba(0, 0, 0, 0.4),
            0 0 40px rgba(154, 151, 243, 0.3);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
          .nav-content {
            flex-wrap: wrap;
            gap: 20px;
          }

          .nav-items {
            order: 3;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
          }

          .metrics-grid {
            grid-template-columns: 1fr;
          }

          .biometric-stats-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};

export default EnhancedDashboard; 