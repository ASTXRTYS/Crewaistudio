import React, { useEffect, useRef } from 'react';

// Neural Network Particle System - Ambient Background
const ParticleBackground = ({ 
  particleCount = 150, 
  connectionDistance = 150,
  mouseInteraction = true,
  colorScheme = 'neural' 
}) => {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const particlesRef = useRef([]);

  // Color schemes based on training guide
  const colorSchemes = {
    neural: {
      particle: 'rgba(154, 151, 243, 0.6)',  // Desaturated purple
      connection: 'rgba(154, 151, 243, 0.15)',
      glow: 'rgba(154, 151, 243, 0.3)'
    },
    biometric: {
      particle: 'rgba(74, 222, 128, 0.6)',   // Success green
      connection: 'rgba(74, 222, 128, 0.15)',
      glow: 'rgba(74, 222, 128, 0.3)'
    },
    alert: {
      particle: 'rgba(248, 113, 113, 0.6)',  // Danger red
      connection: 'rgba(248, 113, 113, 0.15)',
      glow: 'rgba(248, 113, 113, 0.3)'
    }
  };

  const colors = colorSchemes[colorScheme] || colorSchemes.neural;

  class Particle {
    constructor(canvas) {
      this.canvas = canvas;
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.vx = (Math.random() - 0.5) * 0.5;
      this.vy = (Math.random() - 0.5) * 0.5;
      this.radius = Math.random() * 2 + 1;
      this.opacity = Math.random() * 0.5 + 0.3;
    }

    update() {
      // Bounce off edges
      if (this.x < 0 || this.x > this.canvas.width) this.vx *= -1;
      if (this.y < 0 || this.y > this.canvas.height) this.vy *= -1;

      // Update position
      this.x += this.vx;
      this.y += this.vy;

      // Mouse interaction (repel particles)
      if (mouseInteraction) {
        const dx = this.x - mouseRef.current.x;
        const dy = this.y - mouseRef.current.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 100) {
          const force = (100 - distance) / 100;
          this.vx += (dx / distance) * force * 0.5;
          this.vy += (dy / distance) * force * 0.5;
          
          // Damping to prevent excessive speed
          this.vx *= 0.98;
          this.vy *= 0.98;
        }
      }
    }

    draw(ctx) {
      ctx.save();
      
      // Glow effect
      ctx.shadowBlur = 10;
      ctx.shadowColor = colors.glow;
      
      ctx.globalAlpha = this.opacity;
      ctx.fillStyle = colors.particle;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.restore();
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let particles = [];

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      
      // Recreate particles on resize
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle(canvas));
      }
      particlesRef.current = particles;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Mouse tracking
    const handleMouseMove = (e) => {
      mouseRef.current = {
        x: e.clientX,
        y: e.clientY
      };
    };

    if (mouseInteraction) {
      window.addEventListener('mousemove', handleMouseMove);
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update and draw particles
      particles.forEach(particle => {
        particle.update();
        particle.draw(ctx);
      });

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < connectionDistance) {
            ctx.save();
            ctx.globalAlpha = (1 - distance / connectionDistance) * 0.5;
            ctx.strokeStyle = colors.connection;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (mouseInteraction) {
        window.removeEventListener('mousemove', handleMouseMove);
      }
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [particleCount, connectionDistance, mouseInteraction, colors]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: -1,
        opacity: 0.7
      }}
    />
  );
};

export default ParticleBackground; 