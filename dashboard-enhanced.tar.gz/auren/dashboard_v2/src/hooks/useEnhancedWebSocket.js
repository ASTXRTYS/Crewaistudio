import { useState, useEffect, useRef, useCallback } from 'react';

// Enhanced WebSocket Hook with Training Guide Best Practices
const useEnhancedWebSocket = (url, options = {}) => {
  const {
    reconnect = true,
    reconnectInterval = 3000,
    reconnectAttempts = 5,
    heartbeatInterval = 30000,
    messageTypes = {},
    onOpen = () => {},
    onClose = () => {},
    onError = () => {},
    onMessage = () => {},
    channels = []
  } = options;

  const [connectionState, setConnectionState] = useState('disconnected');
  const [lastMessage, setLastMessage] = useState(null);
  const [messageHistory, setMessageHistory] = useState([]);
  const [latency, setLatency] = useState(0);

  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const reconnectCountRef = useRef(0);
  const heartbeatIntervalRef = useRef(null);
  const pingTimestampRef = useRef(null);
  const messageQueueRef = useRef([]);

  // Message type handlers based on training guide
  const messageHandlers = {
    CHART_UPDATE: (data) => {
      console.log('Chart update received:', data);
      return { type: 'chart', data };
    },
    STATUS_CHANGE: (data) => {
      console.log('Status change:', data);
      return { type: 'status', data };
    },
    AGENT_EVENT: (data) => {
      console.log('Agent event:', data);
      return { type: 'agent', data };
    },
    BIOMETRIC_UPDATE: (data) => {
      console.log('Biometric update:', data);
      return { type: 'biometric', data };
    },
    ANOMALY_DETECTED: (data) => {
      console.log('Anomaly detected:', data);
      return { type: 'anomaly', data, priority: 'high' };
    },
    HYPOTHESIS_UPDATE: (data) => {
      console.log('Hypothesis update:', data);
      return { type: 'hypothesis', data };
    },
    KNOWLEDGE_ACCESS: (data) => {
      console.log('Knowledge access:', data);
      return { type: 'knowledge', data };
    },
    // Heartbeat messages
    PING: () => {
      const latency = Date.now() - pingTimestampRef.current;
      setLatency(latency);
      return { type: 'pong', latency };
    },
    PONG: (data) => {
      const latency = Date.now() - pingTimestampRef.current;
      setLatency(latency);
      return { type: 'heartbeat', latency };
    },
    ...messageTypes
  };

  // Connect with exponential backoff
  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    try {
      setConnectionState('connecting');
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = (event) => {
        console.log('WebSocket connected');
        setConnectionState('connected');
        reconnectCountRef.current = 0;
        
        // Subscribe to channels
        if (channels.length > 0) {
          ws.send(JSON.stringify({
            type: 'SUBSCRIBE',
            channels: channels
          }));
        }

        // Process queued messages
        while (messageQueueRef.current.length > 0) {
          const message = messageQueueRef.current.shift();
          ws.send(message);
        }

        // Start heartbeat
        startHeartbeat();
        
        onOpen(event);
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          const { type, payload } = message;

          // Handle structured messages based on type
          if (messageHandlers[type]) {
            const processed = messageHandlers[type](payload);
            setLastMessage(processed);
            setMessageHistory(prev => [...prev.slice(-99), processed]);
            onMessage(processed);
          } else {
            // Fallback for unstructured messages
            setLastMessage(message);
            setMessageHistory(prev => [...prev.slice(-99), message]);
            onMessage(message);
          }
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onerror = (event) => {
        console.error('WebSocket error:', event);
        setConnectionState('error');
        onError(event);
      };

      ws.onclose = (event) => {
        console.log('WebSocket closed:', event.code, event.reason);
        setConnectionState('disconnected');
        stopHeartbeat();
        onClose(event);

        // Reconnect logic with exponential backoff
        if (reconnect && reconnectCountRef.current < reconnectAttempts) {
          const timeout = Math.min(
            reconnectInterval * Math.pow(2, reconnectCountRef.current),
            30000 // Max 30 seconds
          );
          
          console.log(`Reconnecting in ${timeout}ms...`);
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectCountRef.current++;
            connect();
          }, timeout);
        }
      };
    } catch (error) {
      console.error('Failed to create WebSocket:', error);
      setConnectionState('error');
    }
  }, [url, reconnect, reconnectInterval, reconnectAttempts, channels, onOpen, onClose, onError, onMessage]);

  // Heartbeat mechanism
  const startHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }

    heartbeatIntervalRef.current = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        pingTimestampRef.current = Date.now();
        wsRef.current.send(JSON.stringify({
          type: 'PING',
          timestamp: pingTimestampRef.current
        }));
      }
    }, heartbeatInterval);
  }, [heartbeatInterval]);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
      heartbeatIntervalRef.current = null;
    }
  }, []);

  // Send message with queueing
  const sendMessage = useCallback((message) => {
    const messageStr = typeof message === 'string' 
      ? message 
      : JSON.stringify(message);

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(messageStr);
    } else {
      // Queue message if not connected
      messageQueueRef.current.push(messageStr);
      console.log('Message queued, WebSocket not ready');
      
      // Try to reconnect if disconnected
      if (connectionState === 'disconnected') {
        connect();
      }
    }
  }, [connectionState, connect]);

  // Subscribe to channel
  const subscribe = useCallback((channel) => {
    sendMessage({
      type: 'SUBSCRIBE',
      channels: [channel]
    });
  }, [sendMessage]);

  // Unsubscribe from channel
  const unsubscribe = useCallback((channel) => {
    sendMessage({
      type: 'UNSUBSCRIBE',
      channels: [channel]
    });
  }, [sendMessage]);

  // Disconnect
  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    stopHeartbeat();
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, [stopHeartbeat]);

  // Auto-connect on mount
  useEffect(() => {
    connect();
    
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  // Visibility change handling
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        console.log('Page hidden, stopping heartbeat');
        stopHeartbeat();
      } else {
        console.log('Page visible, restarting heartbeat');
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          startHeartbeat();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [startHeartbeat, stopHeartbeat]);

  return {
    connectionState,
    lastMessage,
    messageHistory,
    latency,
    sendMessage,
    subscribe,
    unsubscribe,
    connect,
    disconnect,
    isConnected: connectionState === 'connected'
  };
};

export default useEnhancedWebSocket; 